// main.dart
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';

import 'config/nim_config.dart';
import 'l10n/app_localizations.dart';
import 'models/admin.dart';
import 'models/user.dart';
import 'services/admin_service.dart';
import 'services/user_service.dart';

void main() => runApp(const MyApp());

// ==========================================
// MAIN APP
// ==========================================
class MyApp extends StatefulWidget {
  const MyApp({super.key});
  @override
  State<MyApp> createState() => _MyAppState();
}

class _MyAppState extends State<MyApp> {
  Locale locale = const Locale('id');

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'API Method Tester',
      locale: locale,
      supportedLocales: const [Locale('id'), Locale('en')],
      localizationsDelegates: const [
        AppLocalizations.delegate,
        GlobalMaterialLocalizations.delegate,
        GlobalWidgetsLocalizations.delegate,
        GlobalCupertinoLocalizations.delegate,
      ],
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.blue),
        useMaterial3: true,
      ),
      home: HomeScreen(
        onLanguageChanged: (v) => setState(() => locale = Locale(v)),
      ),
    );
  }
}

// ==========================================
// PAGE 1 - DAFTAR USER & ADMIN (TAB)
// ==========================================
class HomeScreen extends StatefulWidget {
  final Function(String) onLanguageChanged;
  const HomeScreen({super.key, required this.onLanguageChanged});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  late Future<List<User>> futureUsers;
  late Future<List<Admin>> futureAdmins;

  @override
  void initState() {
    super.initState();
    _load();
  }

  void _load() {
    futureUsers = UserService.getUsers();
    futureAdmins = AdminService.getAdmins();
  }

  void refreshData() => setState(_load);

  void _snack(String msg) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(msg)));
  }

  Future<void> _showStorageInfo() async {
    final userPath = await UserService.getJsonFilePath();
    final adminPath = await AdminService.getJsonFilePath();
    if (!mounted) return;
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Penyimpanan File JSON'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text('Data User:', style: TextStyle(fontWeight: FontWeight.bold)),
            SelectableText(userPath, style: const TextStyle(fontFamily: 'monospace', fontSize: 12)),
            const SizedBox(height: 12),
            const Text('Data Admin:', style: TextStyle(fontWeight: FontWeight.bold)),
            SelectableText(adminPath, style: const TextStyle(fontFamily: 'monospace', fontSize: 12)),
          ],
        ),
        actions: [TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Tutup'))],
      ),
    );
  }

  Future<void> _reset() async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Reset Data JSON?'),
        content: const Text('Kembalikan data User dan Admin ke daftar awal?'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Batal')),
          ElevatedButton(
            style: ElevatedButton.styleFrom(backgroundColor: Colors.red, foregroundColor: Colors.white),
            onPressed: () => Navigator.pop(ctx, true),
            child: const Text('Reset'),
          ),
        ],
      ),
    );
    if (ok == true) {
      await UserService.resetToDefault();
      await AdminService.resetToDefault();
      refreshData();
      _snack('Data User & Admin berhasil di-reset');
    }
  }

  Future<void> _deleteAdmin(Admin a) async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Hapus Admin?'),
        content: Text('Hapus ${a.name} (ID ${a.id})?'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Batal')),
          ElevatedButton(
            style: ElevatedButton.styleFrom(backgroundColor: Colors.red, foregroundColor: Colors.white),
            onPressed: () => Navigator.pop(ctx, true),
            child: const Text('Hapus'),
          ),
        ],
      ),
    );
    if (ok != true) return;
    final success = await AdminService.deleteAdmin(a.id);
    refreshData();
    _snack(success ? 'Admin ID ${a.id} berhasil dihapus' : 'Gagal menghapus admin');
  }

  Widget _asyncList<T>(
      Future<List<T>> future,
      AppLocalizations l,
      Widget Function(T) itemBuilder,
      ) {
    return FutureBuilder<List<T>>(
      future: future,
      builder: (context, snap) {
        if (snap.connectionState == ConnectionState.waiting) {
          return const Center(child: CircularProgressIndicator());
        }
        if (snap.hasError) {
          return Center(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                const Icon(Icons.error_outline, color: Colors.red, size: 50),
                const SizedBox(height: 12),
                Text(l.errorMessage),
                ElevatedButton(onPressed: refreshData, child: Text(l.retry)),
              ],
            ),
          );
        }
        final items = snap.data ?? [];
        if (items.isEmpty) return Center(child: Text(l.noData));
        return RefreshIndicator(
          onRefresh: () async => refreshData(),
          child: ListView.builder(
            padding: const EdgeInsets.all(16),
            itemCount: items.length,
            itemBuilder: (_, i) => itemBuilder(items[i]),
          ),
        );
      },
    );
  }

  Widget _avatar(String name, Color color) => CircleAvatar(
    backgroundColor: color.withAlpha(40),
    child: Text(
      name.isEmpty ? '?' : name[0],
      style: TextStyle(color: color, fontWeight: FontWeight.bold),
    ),
  );

  @override
  Widget build(BuildContext context) {
    final l = AppLocalizations.of(context)!;

    return DefaultTabController(
      length: 2,
      child: Scaffold(
        appBar: AppBar(
          title: const Text('API Method Tester'),
          backgroundColor: Colors.blue,
          foregroundColor: Colors.white,
          bottom: TabBar(
            labelColor: Colors.white,
            unselectedLabelColor: Colors.white70,
            indicatorColor: Colors.white,
            tabs: [
              Tab(icon: const Icon(Icons.people), text: l.users),
              Tab(icon: const Icon(Icons.admin_panel_settings), text: l.admins),
            ],
          ),
          actions: [
            IconButton(icon: const Icon(Icons.info_outline), tooltip: 'Lokasi File JSON', onPressed: _showStorageInfo),
            IconButton(icon: const Icon(Icons.restore), tooltip: 'Reset Data JSON', onPressed: _reset),
            PopupMenuButton<String>(
              icon: const Icon(Icons.language),
              onSelected: widget.onLanguageChanged,
              itemBuilder: (_) => const [
                PopupMenuItem(value: 'id', child: Text('Bahasa Indonesia')),
                PopupMenuItem(value: 'en', child: Text('English')),
              ],
            ),
          ],
        ),
        floatingActionButton: FloatingActionButton.extended(
          onPressed: () => Navigator.push(
            context,
            MaterialPageRoute(builder: (_) => const ApiTesterScreen()),
          ).then((_) => refreshData()),
          icon: const Icon(Icons.api),
          label: const Text('Test API'),
        ),
        body: TabBarView(
          children: [
            // ---- TAB USER ----
            _asyncList<User>(
              futureUsers,
              l,
                  (u) => Card(
                margin: const EdgeInsets.only(bottom: 12),
                child: ListTile(
                  leading: _avatar(u.name, Colors.blue),
                  title: Text(u.name, style: const TextStyle(fontWeight: FontWeight.bold)),
                  subtitle: Text('${u.email}\n${u.city}'),
                  isThreeLine: true,
                  trailing: const Icon(Icons.chevron_right),
                  onTap: () => Navigator.push(
                    context,
                    MaterialPageRoute(builder: (_) => DetailScreen(id: u.id, isAdmin: false)),
                  ).then((_) => refreshData()),
                ),
              ),
            ),
            // ---- TAB ADMIN ----
            _asyncList<Admin>(
              futureAdmins,
              l,
                  (a) => Card(
                margin: const EdgeInsets.only(bottom: 12),
                child: ListTile(
                  leading: _avatar(a.name, Colors.deepOrange),
                  title: Text(a.name, style: const TextStyle(fontWeight: FontWeight.bold)),
                  subtitle: Text('${a.email}\n${a.department}'),
                  isThreeLine: true,
                  trailing: IconButton(
                    icon: const Icon(Icons.delete, color: Colors.red),
                    tooltip: 'Hapus Admin',
                    onPressed: () => _deleteAdmin(a),
                  ),
                  onTap: () => Navigator.push(
                    context,
                    MaterialPageRoute(builder: (_) => DetailScreen(id: a.id, isAdmin: true)),
                  ).then((_) => refreshData()),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// ==========================================
// PAGE 2 - DETAIL USER / ADMIN BERDASARKAN ID
// ==========================================
class DetailScreen extends StatefulWidget {
  final int id;
  final bool isAdmin;
  const DetailScreen({super.key, required this.id, required this.isAdmin});

  @override
  State<DetailScreen> createState() => _DetailScreenState();
}

class _DetailScreenState extends State<DetailScreen> {
  late Future<dynamic> future;

  @override
  void initState() {
    super.initState();
    future = widget.isAdmin
        ? AdminService.getAdmin(widget.id)
        : UserService.getUser(widget.id);
  }

  Widget _row(String label, String value) => Padding(
    padding: const EdgeInsets.symmetric(vertical: 8),
    child: Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        SizedBox(width: 110, child: Text(label, style: const TextStyle(fontWeight: FontWeight.bold))),
        Expanded(child: Text(value)),
      ],
    ),
  );

  @override
  Widget build(BuildContext context) {
    final l = AppLocalizations.of(context)!;

    return Scaffold(
      appBar: AppBar(
        title: Text(widget.isAdmin ? l.adminDetailTitle : l.detailTitle),
        backgroundColor: Colors.blue,
        foregroundColor: Colors.white,
      ),
      body: FutureBuilder<dynamic>(
        future: future,
        builder: (context, snap) {
          if (snap.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          }
          if (snap.hasError) {
            return Center(child: Text(snap.error.toString().replaceFirst('Exception: ', '')));
          }
          final data = snap.data;
          return Padding(
            padding: const EdgeInsets.all(20),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Card(
                  child: Padding(
                    padding: const EdgeInsets.all(16),
                    child: Column(
                      children: [
                        _row('ID', data.id.toString()),
                        _row('Name', data.name),
                        _row(l.email, data.email),
                        if (widget.isAdmin)
                          _row(l.department, (data as Admin).department)
                        else
                          _row(l.city, (data as User).city),
                      ],
                    ),
                  ),
                ),
                if (widget.isAdmin) ...[
                  const SizedBox(height: 20),
                  SizedBox(
                    width: double.infinity,
                    height: 48,
                    child: ElevatedButton.icon(
                      style: ElevatedButton.styleFrom(backgroundColor: Colors.red, foregroundColor: Colors.white),
                      icon: const Icon(Icons.delete),
                      label: const Text('Hapus Admin'),
                      onPressed: () async {
                        final ok = await AdminService.deleteAdmin(widget.id);
                        if (!context.mounted) return;
                        ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                          content: Text(ok ? 'Admin berhasil dihapus' : 'Gagal menghapus admin'),
                        ));
                        if (ok) Navigator.pop(context);
                      },
                    ),
                  ),
                ],
              ],
            ),
          );
        },
      ),
    );
  }
}

// ==========================================
// PAGE 3 - API METHOD TESTER (CRUD USER)
// ==========================================
class ApiTesterScreen extends StatefulWidget {
  final int? initialId;
  const ApiTesterScreen({super.key, this.initialId});

  @override
  State<ApiTesterScreen> createState() => _ApiTesterScreenState();
}

class _ApiTesterScreenState extends State<ApiTesterScreen> {
  String selectedMethod = 'GET';
  final idController = TextEditingController();
  final nameController = TextEditingController();
  final emailController = TextEditingController();

  bool isLoading = false;
  dynamic result;
  String? errorMessage;

  @override
  void initState() {
    super.initState();
    if (widget.initialId != null) idController.text = widget.initialId.toString();
  }

  @override
  void dispose() {
    idController.dispose();
    nameController.dispose();
    emailController.dispose();
    super.dispose();
  }

  void showMessage(String m) =>
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(m)));

  Future<void> sendRequest() async {
    final id = int.tryParse(idController.text);

    if (selectedMethod != 'POST' && id == null) {
      showMessage('Masukkan ID pengguna yang valid');
      return;
    }
    if (selectedMethod != 'GET' && selectedMethod != 'DELETE' && nameController.text.trim().isEmpty) {
      showMessage('Nama tidak boleh kosong');
      return;
    }
    if ((selectedMethod == 'POST' || selectedMethod == 'PUT') && emailController.text.trim().isEmpty) {
      showMessage('Email tidak boleh kosong');
      return;
    }

    setState(() {
      isLoading = true;
      result = null;
      errorMessage = null;
    });

    try {
      dynamic response;
      final name = nameController.text.trim();
      final email = emailController.text.trim();

      switch (selectedMethod) {
        case 'GET':
          response = (await UserService.getUser(id!)).toJson();
          break;
        case 'POST':
          response = (await UserService.createUser(name, email)).toJson();
          break;
        case 'PUT':
          response = (await UserService.updateUser(id!, name, email)).toJson();
          break;
        case 'PATCH':
          response = (await UserService.patchUser(id!, name)).toJson();
          break;
        case 'DELETE':
          final ok = await UserService.deleteUser(id!);
          response = {
            'success': ok,
            'message': ok ? 'Pengguna berhasil dihapus' : 'Gagal menghapus pengguna',
          };
          break;
      }
      if (mounted) setState(() => result = response);
    } catch (e) {
      if (mounted) setState(() => errorMessage = e.toString().replaceFirst('Exception: ', ''));
    } finally {
      if (mounted) setState(() => isLoading = false);
    }
  }

  Widget _label(String t) => Padding(
    padding: const EdgeInsets.only(bottom: 8),
    child: Text(t, style: const TextStyle(fontWeight: FontWeight.bold)),
  );

  @override
  Widget build(BuildContext context) {
    final isGet = selectedMethod == 'GET';
    final isPost = selectedMethod == 'POST';
    final isPut = selectedMethod == 'PUT';
    final isPatch = selectedMethod == 'PATCH';
    final isDelete = selectedMethod == 'DELETE';

    final info = isGet
        ? 'GET: Mengambil data pengguna berdasarkan ID.'
        : isPost
        ? 'POST: Menambah pengguna baru dengan ID otomatis dari NIM ($nimUserId).'
        : isPut
        ? 'PUT: Mengganti nama dan email pengguna.'
        : isPatch
        ? 'PATCH: Mengubah nama dan menambahkan "${UserService.patchSuffix}".'
        : 'DELETE: Menghapus pengguna berdasarkan ID.';

    return Scaffold(
      appBar: AppBar(
        title: const Text('API Method Tester'),
        backgroundColor: Colors.blue,
        foregroundColor: Colors.white,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text('Request Configuration', style: TextStyle(fontSize: 21, fontWeight: FontWeight.bold)),
            const SizedBox(height: 6),
            const Text('Pilih HTTP method dan masukkan data yang ingin dikirim.', style: TextStyle(color: Colors.grey)),
            const SizedBox(height: 24),

            _label('HTTP Method'),
            DropdownButtonFormField<String>(
              initialValue: selectedMethod,
              decoration: const InputDecoration(border: OutlineInputBorder(), prefixIcon: Icon(Icons.api)),
              items: const [
                DropdownMenuItem(value: 'GET', child: Text('GET - Retrieve Data')),
                DropdownMenuItem(value: 'POST', child: Text('POST - Create Data')),
                DropdownMenuItem(value: 'PUT', child: Text('PUT - Replace Data')),
                DropdownMenuItem(value: 'PATCH', child: Text('PATCH - Update Data')),
                DropdownMenuItem(value: 'DELETE', child: Text('DELETE - Remove Data')),
              ],
              onChanged: (v) => setState(() {
                selectedMethod = v!;
                result = null;
                errorMessage = null;
              }),
            ),
            const SizedBox(height: 20),

            if (!isPost) ...[
              _label('User ID'),
              TextField(
                controller: idController,
                keyboardType: TextInputType.number,
                decoration: const InputDecoration(
                  border: OutlineInputBorder(),
                  hintText: 'Contoh: 1',
                  prefixIcon: Icon(Icons.numbers),
                ),
              ),
              const SizedBox(height: 20),
            ],

            if (!isGet && !isDelete) ...[
              _label('Name'),
              TextField(
                controller: nameController,
                decoration: const InputDecoration(
                  border: OutlineInputBorder(),
                  hintText: 'Masukkan nama pengguna',
                  prefixIcon: Icon(Icons.person),
                ),
              ),
              const SizedBox(height: 20),
            ],

            if (isPost || isPut) ...[
              _label('Email'),
              TextField(
                controller: emailController,
                keyboardType: TextInputType.emailAddress,
                decoration: const InputDecoration(
                  border: OutlineInputBorder(),
                  hintText: 'Masukkan email pengguna',
                  prefixIcon: Icon(Icons.email),
                ),
              ),
              const SizedBox(height: 20),
            ],

            Container(
              width: double.infinity,
              padding: const EdgeInsets.all(14),
              decoration: BoxDecoration(
                color: Colors.blue.withAlpha(20),
                borderRadius: BorderRadius.circular(12),
              ),
              child: Text(info, style: const TextStyle(fontSize: 13)),
            ),
            const SizedBox(height: 24),

            SizedBox(
              width: double.infinity,
              height: 50,
              child: ElevatedButton.icon(
                onPressed: isLoading ? null : sendRequest,
                icon: isLoading
                    ? const SizedBox(
                  width: 18,
                  height: 18,
                  child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white),
                )
                    : const Icon(Icons.send),
                label: Text(isLoading ? 'Sending Request...' : 'Send Request'),
                style: ElevatedButton.styleFrom(backgroundColor: Colors.blue, foregroundColor: Colors.white),
              ),
            ),
            const SizedBox(height: 30),

            if (result != null || errorMessage != null) ...[
              const Text('Response Result', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
              const SizedBox(height: 12),
              Container(
                width: double.infinity,
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: (errorMessage != null ? Colors.red : Colors.green).withAlpha(20),
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: errorMessage != null ? Colors.red : Colors.green),
                ),
                child: SelectableText(
                  errorMessage ?? const JsonEncoder.withIndent('  ').convert(result),
                  style: const TextStyle(fontFamily: 'monospace', fontSize: 12),
                ),
              ),
            ],
          ],
        ),
      ),
    );
  }
}
