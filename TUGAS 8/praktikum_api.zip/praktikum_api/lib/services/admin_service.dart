import '../config/nim_config.dart';
import '../models/admin.dart';
import 'json_store.dart';

class AdminService {
  static const JsonStore _store = JsonStore('admins.json', 'admins_json');

  static Future<String> getJsonFilePath() => _store.location();

  static Future<List<Admin>> _load() async {
    final raw = await _store.read();
    if (raw != null) {
      return raw.map((e) => Admin.fromJson(Map<String, dynamic>.from(e))).toList();
    }
    final initial = _defaultAdmins();
    await _save(initial);
    return initial;
  }

  static Future<void> _save(List<Admin> admins) =>
      _store.write(admins.map((a) => a.toJson()).toList());

  // GET semua admin
  static Future<List<Admin>> getAdmins() async {
    await Future.delayed(const Duration(milliseconds: 200));
    return _load();
  }

  // GET satu admin berdasarkan ID
  static Future<Admin> getAdmin(int id) async {
    await Future.delayed(const Duration(milliseconds: 200));
    final admins = await _load();
    final i = admins.indexWhere((a) => a.id == id);
    if (i == -1) throw Exception('Data admin dengan ID $id tidak ditemukan');
    return admins[i];
  }

  // DELETE admin berdasarkan ID
  static Future<bool> deleteAdmin(int id) async {
    await Future.delayed(const Duration(milliseconds: 300));
    final admins = await _load();
    final i = admins.indexWhere((a) => a.id == id);
    if (i == -1) return false;
    admins.removeAt(i);
    await _save(admins);
    return true;
  }

  static Future<void> resetToDefault() async {
    await _store.clear();
    await _save(_defaultAdmins());
  }

  // Data awal: salah satunya memakai ID Admin dari rumus 792 + N
  static List<Admin> _defaultAdmins() => [
    Admin(id: 101, name: 'Budi Santoso', email: 'budi@campus.ac.id', department: 'Akademik'),
    Admin(id: 102, name: 'Siti Aminah', email: 'siti@campus.ac.id', department: 'Keuangan'),
    Admin(id: 103, name: 'Rizky Pratama', email: 'rizky@campus.ac.id', department: 'Kemahasiswaan'),
    Admin(id: nimAdminId, name: 'Naswa Nabila Rahman', email: 'naswa@campus.ac.id', department: 'Teknologi Informasi'),
  ];
}