import 'dart:convert';
import 'package:http/http.dart' as http;
import '../config/nim_config.dart';
import '../models/user.dart';
import 'json_store.dart';

class UserService {
  static const String baseUrl = 'https://jsonplaceholder.typicode.com';
  static const String patchSuffix = ' - Flutter Developer';
  static const JsonStore _store = JsonStore('users.json', 'users_json');

  static Future<String> getJsonFilePath() => _store.location();

  // ---------- helper internal ----------
  static Future<List<User>> _fetchInitial() async {
    try {
      final res = await http
          .get(Uri.parse('$baseUrl/users'))
          .timeout(const Duration(seconds: 4));
      if (res.statusCode == 200) {
        final decoded = jsonDecode(res.body);
        if (decoded is List && decoded.isNotEmpty) {
          return decoded
              .map((e) => User.fromJson(Map<String, dynamic>.from(e)))
              .toList();
        }
      }
    } catch (_) {}
    return _defaultUsers();
  }

  static Future<List<User>> _load() async {
    final raw = await _store.read();
    if (raw != null) {
      return raw.map((e) => User.fromJson(Map<String, dynamic>.from(e))).toList();
    }
    final initial = await _fetchInitial();
    await _save(initial);
    return initial;
  }

  static Future<void> _save(List<User> users) =>
      _store.write(users.map((u) => u.toJson()).toList());

  // ---------- GET ----------
  static Future<List<User>> getUsers() async {
    await Future.delayed(const Duration(milliseconds: 200));
    return _load();
  }

  static Future<User> getUser(int id) async {
    await Future.delayed(const Duration(milliseconds: 200));
    final users = await _load();
    final index = users.indexWhere((u) => u.id == id);
    if (index == -1) throw Exception('Data pengguna dengan ID $id tidak ditemukan');
    return users[index];
  }

  // ---------- POST (ID dari NIM) ----------
  static Future<User> createUser(String name, String email) async {
    await Future.delayed(const Duration(milliseconds: 300));
    final users = await _load();
    if (users.any((u) => u.id == nimUserId)) {
      throw Exception('User dengan ID $nimUserId sudah ada. Hapus dulu (DELETE) sebelum POST ulang.');
    }
    final user = User(id: nimUserId, name: name, email: email, city: 'Indonesia');
    users.add(user);
    await _save(users);
    return user;
  }

  // ---------- PUT: ganti nama + email ----------
  static Future<User> updateUser(int id, String name, String email) async {
    await Future.delayed(const Duration(milliseconds: 300));
    final users = await _load();
    final i = users.indexWhere((u) => u.id == id);
    if (i == -1) throw Exception('Gagal memperbarui pengguna: ID $id tidak ditemukan');
    final old = users[i];
    users[i] = User(id: old.id, name: name, email: email, city: old.city);
    await _save(users);
    return users[i];
  }

  // ---------- PATCH: nama + " - Flutter Developer" ----------
  static Future<User> patchUser(int id, String name) async {
    await Future.delayed(const Duration(milliseconds: 300));
    final users = await _load();
    final i = users.indexWhere((u) => u.id == id);
    if (i == -1) throw Exception('Gagal mengubah nama pengguna: ID $id tidak ditemukan');
    final old = users[i];
    users[i] = User(id: old.id, name: '$name$patchSuffix', email: old.email, city: old.city);
    await _save(users);
    return users[i];
  }

  // ---------- DELETE ----------
  static Future<bool> deleteUser(int id) async {
    await Future.delayed(const Duration(milliseconds: 300));
    final users = await _load();
    final i = users.indexWhere((u) => u.id == id);
    if (i == -1) return false;
    users.removeAt(i);
    await _save(users);
    return true;
  }

  static Future<void> resetToDefault() async {
    await _store.clear();
    await _save(_defaultUsers());
  }

  static List<User> _defaultUsers() => [
    User(id: 1, name: 'Leanne Graham', email: 'Sincere@april.biz', city: 'Gwenborough'),
    User(id: 2, name: 'Ervin Howell', email: 'Shanna@melissa.tv', city: 'Wisokyburgh'),
    User(id: 3, name: 'Clementine Bauch', email: 'Nathan@yesenia.net', city: 'McKenziehaven'),
    User(id: 4, name: 'Patricia Lebsack', email: 'Julianne.OConner@kory.org', city: 'South Elvis'),
    User(id: 5, name: 'Chelsey Dietrich', email: 'Lucio_Hettinger@annie.ca', city: 'Roscoeview'),
    User(id: 6, name: 'Mrs. Dennis Schulist', email: 'Karley_Dach@jasper.info', city: 'South Christy'),
    User(id: 7, name: 'Kurtis Weissnat', email: 'Telly.Hoeger@billy.biz', city: 'Howemouth'),
    User(id: 8, name: 'Nicholas Runolfsdottir V', email: 'Sherwood@rosamond.me', city: 'Aliyaview'),
    User(id: 9, name: 'Glenna Reichert', email: 'Chaim_McDermott@dana.io', city: 'Bartholomebury'),
    User(id: 10, name: 'Clementina DuBuque', email: 'Rey.Padberg@karina.biz', city: 'Lebsackbury'),
  ];
}