import 'dart:convert';
import 'dart:io' as io;
import 'package:flutter/foundation.dart';
import 'package:path_provider/path_provider.dart';
import 'package:shared_preferences/shared_preferences.dart';

/// Penyimpanan JSON lokal: file di HP/Desktop, SharedPreferences (LocalStorage) di Web.
class JsonStore {
  final String fileName;
  final String webKey;
  const JsonStore(this.fileName, this.webKey);

  Future<io.File> _file() async {
    final dir = await getApplicationDocumentsDirectory();
    return io.File('${dir.path}/$fileName');
  }

  Future<String> location() async {
    if (kIsWeb) return 'Browser LocalStorage\nKey: "$webKey"';
    return (await _file()).path;
  }

  Future<List<dynamic>?> read() async {
    try {
      if (kIsWeb) {
        final prefs = await SharedPreferences.getInstance();
        final s = prefs.getString(webKey);
        if (s == null || s.isEmpty) return null;
        return jsonDecode(s) as List<dynamic>;
      }
      final file = await _file();
      if (!await file.exists()) return null;
      final s = await file.readAsString();
      if (s.trim().isEmpty) return null;
      return jsonDecode(s) as List<dynamic>;
    } catch (_) {
      return null;
    }
  }

  Future<void> write(List<dynamic> data) async {
    final s = const JsonEncoder.withIndent('  ').convert(data);
    if (kIsWeb) {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setString(webKey, s);
    } else {
      await (await _file()).writeAsString(s);
    }
  }

  Future<void> clear() async {
    if (kIsWeb) {
      final prefs = await SharedPreferences.getInstance();
      await prefs.remove(webKey);
    } else {
      final file = await _file();
      if (await file.exists()) await file.delete();
    }
  }
}