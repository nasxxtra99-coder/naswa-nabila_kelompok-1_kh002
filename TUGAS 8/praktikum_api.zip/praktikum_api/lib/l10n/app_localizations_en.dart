// ignore: unused_import
import 'package:intl/intl.dart' as intl;

import 'app_localizations.dart';

// ignore_for_file: type=lint

/// The translations for English (`en`).
class AppLocalizationsEn extends AppLocalizations {
  AppLocalizationsEn([String locale = 'en']) : super(locale);

  @override
  String get appTittle => 'Student Directory';

  @override
  String get detailTitle => 'User Details';

  @override
  String get adminDetailTitle => 'Admin Details';

  @override
  String get users => 'Users';

  @override
  String get admins => 'Admins';

  @override
  String get email => 'Email';

  @override
  String get city => 'City';

  @override
  String get department => 'Department';

  @override
  String get language => 'Language';

  @override
  String get errorMessage => 'Failed to retrieve data';

  @override
  String get retry => 'Try Again';

  @override
  String get noData => 'No data available';
}
