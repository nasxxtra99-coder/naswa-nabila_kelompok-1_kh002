// NIM: 20240801197 -> 3 digit terakhir = 197
// Angka tengah (9) digeser ke belakang -> 179
// Jika dosen memakai 197 apa adanya (seperti hitungan contoh di soal: 1499 + 345),
// cukup ubah nimN menjadi 197.
const int nimN = 179;

const int nimUserId = 1499 + nimN; // 1678
const int nimAdminId = 792 + nimN; // 971