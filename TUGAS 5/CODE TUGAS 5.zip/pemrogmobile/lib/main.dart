import 'package:flutter/material.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'firebase_options.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp(
    options: DefaultFirebaseOptions.currentPlatform,
  );
  runApp(const StokBarangApp());
}

class StokBarangApp extends StatelessWidget {
  const StokBarangApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Pencatatan Stok Barang - NIM Ganjil',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        primarySwatch: Colors.blue,
        useMaterial3: true,
      ),
      home: const FormStokBarangPage(),
    );
  }
}

class FormStokBarangPage extends StatefulWidget {
  const FormStokBarangPage({super.key});

  @override
  State<FormStokBarangPage> createState() => _FormStokBarangPageState();
}

class _FormStokBarangPageState extends State<FormStokBarangPage> {
  final _formKey = GlobalKey<FormState>();

  final TextEditingController _namaBarangController = TextEditingController();
  final TextEditingController _tanggalMasukController = TextEditingController();
  final TextEditingController _tanggalKeluarController = TextEditingController();
  final TextEditingController _kodeBarangController = TextEditingController();
  final TextEditingController _jumlahStokController = TextEditingController();

  bool _isLoading = false;

  Future<void> _simpanBarang() async {
    if (_formKey.currentState!.validate()) {
      setState(() {
        _isLoading = true;
      });

      try {
        String namaBarang = _namaBarangController.text.trim();
        String tanggalMasuk = _tanggalMasukController.text.trim();
        String tanggalKeluar = _tanggalKeluarController.text.trim();

        // NIM Ganjil: Kode Barang berupa Bilangan Desimal (double), min 6 digit berakhiran 97
        double kodeBarang = double.parse(_kodeBarangController.text.trim());

        // Jumlah Stok berupa Angka Bulat (int)
        int jumlahStok = int.parse(_jumlahStokController.text.trim());

        await FirebaseFirestore.instance.collection('stok_barang').add({
          'nama_barang': namaBarang,
          'tanggal_masuk': tanggalMasuk,
          'tanggal_keluar': tanggalKeluar,
          'kode_barang': kodeBarang, // Tersimpan sebagai tipe Number (Double/Desimal) di Firestore
          'jumlah_stok': jumlahStok, // Tersimpan sebagai tipe Number (Integer) di Firestore
          'waktu': FieldValue.serverTimestamp(),
        });

        if (!mounted) return;

        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Data barang berhasil disimpan!'),
            backgroundColor: Colors.green,
          ),
        );

        _namaBarangController.clear();
        _tanggalMasukController.clear();
        _tanggalKeluarController.clear();
        _kodeBarangController.clear();
        _jumlahStokController.clear();
      } catch (e) {
        if (!mounted) return;

        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Gagal menyimpan data: $e'),
            backgroundColor: Colors.red,
          ),
        );
      } finally {
        if (mounted) {
          setState(() {
            _isLoading = false;
          });
        }
      }
    }
  }

  @override
  void dispose() {
    _namaBarangController.dispose();
    _tanggalMasukController.dispose();
    _tanggalKeluarController.dispose();
    _kodeBarangController.dispose();
    _jumlahStokController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Input Stok Barang (NIM Ganjil)'),
        centerTitle: true,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16.0),
        child: Form(
          key: _formKey,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              // 1. Nama Barang (Inisial Nama Depan, cth: Naswa Buku)
              TextFormField(
                controller: _namaBarangController,
                decoration: const InputDecoration(
                  labelText: 'Nama Barang ',
                  border: OutlineInputBorder(),
                  prefixIcon: Icon(Icons.inventory),
                ),
                validator: (value) {
                  if (value == null || value.trim().isEmpty) {
                    return 'Nama barang wajib diisi';
                  }
                  return null;
                },
              ),
              const SizedBox(height: 16),

              // 2. Tanggal Masuk Barang
              TextFormField(
                controller: _tanggalMasukController,
                decoration: const InputDecoration(
                  labelText: 'Tanggal Masuk ',
                  border: OutlineInputBorder(),
                  prefixIcon: Icon(Icons.calendar_today),
                ),
                validator: (value) {
                  if (value == null || value.trim().isEmpty) {
                    return 'Tanggal masuk wajib diisi';
                  }
                  return null;
                },
              ),
              const SizedBox(height: 16),

              // 3. Tanggal Keluar Barang
              TextFormField(
                controller: _tanggalKeluarController,
                decoration: const InputDecoration(
                  labelText: 'Tanggal Keluar ',
                  border: OutlineInputBorder(),
                  prefixIcon: Icon(Icons.calendar_month),
                ),
                validator: (value) {
                  if (value == null || value.trim().isEmpty) {
                    return 'Tanggal keluar wajib diisi';
                  }
                  return null;
                },
              ),
              const SizedBox(height: 16),

              // 4. Kode Barang (Min 6 angka, dua angka terakhir 97, Desimal untuk NIM Ganjil)
              TextFormField(
                controller: _kodeBarangController,
                keyboardType: const TextInputType.numberWithOptions(decimal: true),
                decoration: const InputDecoration(
                  labelText: 'Kode Barang (Min 6 digit)',
                  border: OutlineInputBorder(),
                  prefixIcon: Icon(Icons.qr_code),
                ),
                validator: (value) {
                  if (value == null || value.trim().isEmpty) {
                    return 'Kode barang wajib diisi';
                  }
                  final parsed = double.tryParse(value.trim());
                  if (parsed == null) {
                    return 'Kode barang harus berupa angka desimal yang valid';
                  }
                  if (value.trim().length < 6) {
                    return 'Kode barang minimal 6 karakter/angka';
                  }
                  if (!value.trim().endsWith('97')) {
                    return 'Dua angka terakhir kode barang harus 97 (sesuai NIM)';
                  }
                  return null;
                },
              ),
              const SizedBox(height: 16),

              // 5. Jumlah Stok (Integer / Bulat, Tidak Negatif)
              TextFormField(
                controller: _jumlahStokController,
                keyboardType: TextInputType.number,
                decoration: const InputDecoration(
                  labelText: 'Jumlah Stok (Bilangan Bulat)',
                  border: OutlineInputBorder(),
                  prefixIcon: Icon(Icons.numbers),
                ),
                validator: (value) {
                  if (value == null || value.trim().isEmpty) {
                    return 'Jumlah stok wajib diisi';
                  }
                  final stok = int.tryParse(value.trim());
                  if (stok == null) {
                    return 'Jumlah stok harus berupa bilangan bulat';
                  }
                  if (stok < 0) {
                    return 'Jumlah stok tidak boleh negatif';
                  }
                  return null;
                },
              ),
              const SizedBox(height: 24),

              // Tombol Simpan Barang
              ElevatedButton(
                onPressed: _isLoading ? null : _simpanBarang,
                style: ElevatedButton.styleFrom(
                  padding: const EdgeInsets.symmetric(vertical: 16),
                ),
                child: _isLoading
                    ? const CircularProgressIndicator(color: Colors.white)
                    : const Text(
                  'Simpan Barang',
                  style: TextStyle(fontSize: 16),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}