import 'package:flutter/material.dart';
import 'theme/app_theme.dart';
import 'widgets/app.button.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      theme: AppTheme.light,
      home: const ProfilePage(),
    );
  }
}

class ProfilePage extends StatelessWidget {
  const ProfilePage({super.key});

  @override
  Widget build(BuildContext context) {
    // Nilai d berdasarkan digit terakhir NIM (d = 0)
    const double paddingCard = 16.0;
    const double roundedCard = 8.0;
    const double tinggiTombol = 40.0;
    const double roundedTombol = 4.0;
    const double ukuranAvatar = 40.0;
    const double jarakNamaNim = 8.0;

    return Scaffold(
      appBar: AppBar(
        title: const Text('Personal Profile Card'),
      ),
      body: Center(
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Card(
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(roundedCard),
            ),
            child: Padding(
              padding: const EdgeInsets.all(paddingCard),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  const CircleAvatar(
                    radius: ukuranAvatar,
                    child: Icon(Icons.person, size: ukuranAvatar),
                  ),
                  const SizedBox(height: 16),
                  const Text('Naswa Nabila Rahman'),
                  const SizedBox(height: jarakNamaNim),
                  const Text('NIM: 20240801197'),
                  const SizedBox(height: 8),
                  const Text('Teknik Informatika'),
                  const SizedBox(height: 12),
                  const Text(
                    'Mahasiswi Teknologi Informasi Universitas Esa Unggul yang tertarik dalam pengembangan aplikasi mobile dan web.',
                    textAlign: TextAlign.center,
                  ),
                  const SizedBox(height: 20),
                  AppButton(
                    label: 'Kunjungi GitHub Saya',
                    icon: Icons.code,
                    url: 'https://github.com/nasxxtra99-coder/naswa-nabila_kelompok-1_kh002',
                    height: tinggiTombol,
                    borderRadius: roundedTombol,
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}