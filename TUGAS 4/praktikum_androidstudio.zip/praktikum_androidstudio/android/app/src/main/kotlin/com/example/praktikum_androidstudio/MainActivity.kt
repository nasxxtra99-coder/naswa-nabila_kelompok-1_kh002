package com.example.praktikum_androidstudio

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
